﻿namespace MaterialDesignDemo.TransitionsDemo
{
    public class Slide7_MasterModel
    {
    }

    public class Slide8_DetailsModel
    {

    }
}
