﻿using System.Windows.Controls;

namespace MaterialDesignDemo
{
    /// <summary>
    /// Interaction logic for Transitions.xaml
    /// </summary>
    public partial class Transitions : UserControl
    {
        public Transitions()
        {
            InitializeComponent();
        }
    }
}
