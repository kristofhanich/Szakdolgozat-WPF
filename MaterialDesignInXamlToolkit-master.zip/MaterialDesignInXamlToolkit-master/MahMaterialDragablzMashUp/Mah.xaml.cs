﻿using System.Windows.Controls;

namespace MahMaterialDragablzMashUp
{
    /// <summary>
    /// Interaction logic for MahApps.xaml
    /// </summary>
    public partial class Mah : UserControl
    {
        public Mah()
        {
            InitializeComponent();
        }
    }
}
